
SCREEN_HEIGHT = 500
SCREEN_WIDTH = 800
FPS = 320

RUN = True

#COLORS

WHITE = (225,225,225)
BLACK = (0,0,0)

# CHACRATER

X = 50
Y = 365

CH_WIDTH = 64
CH_HEIGHT = 64

VEL = 5

isJump = False
jumpCount = 10

isCrouch = False

isAttack= False

WALK_COUNT = 0